package my.units

import model.Vec2Int
import my.MovableUnit
import my.MyUnit

class FighterUnit(
        id: Int,
        pos: Vec2Int,
        override var health: Int,
        override var maxHealth: Int,
        override val damage: Int,
        override val range: Int
) : MovableUnit(id, pos), MyUnit {
    var strength = 0
    override val our: Boolean get() = true
    override val size: Int get() = 1
}