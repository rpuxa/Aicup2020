package my

import model.PlayerView
import model.Vec2Int
import my.strategies.BuildStrategy
import my.strategies.FarmingStrategy


class WorkerUnit(id: Int, pos: Vec2Int) : MovableUnit(id, pos) {
    val buildingPlan: BuildingPlan?
        get() {
            val strategy = currentStrategy
            return if (strategy is BuildStrategy) strategy.plan else null
        }
}