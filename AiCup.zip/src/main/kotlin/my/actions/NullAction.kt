package my.actions

import model.EntityAction
import my.MovableUnit

object NullAction : UnitAction {
    private val empty = EntityAction()

    override fun perform(unit: MovableUnit): EntityAction {
        return empty
    }
}
