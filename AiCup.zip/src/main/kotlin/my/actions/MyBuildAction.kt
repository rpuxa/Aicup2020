package my.actions

import model.*
import my.MovableUnit
import my.WorkerUnit

class MyBuildAction(private val type: EntityType, private val location: Vec2Int) : UnitAction {

    override fun perform(unit: MovableUnit): EntityAction {
        return EntityAction().apply {
            buildAction = BuildAction(type, location)
        }
    }
}

