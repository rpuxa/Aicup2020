package my.actions

import model.EntityAction
import model.AttackAction
import model.Vec2Int
import my.MovableUnit
import my.view

class MyAttackAction(val target: Int) : UnitAction {


    override fun perform(unit: MovableUnit): EntityAction {
        return EntityAction().apply {
            attackAction = AttackAction(target, null)
        }
    }
}