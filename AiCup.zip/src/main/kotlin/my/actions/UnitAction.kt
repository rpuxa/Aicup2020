package my.actions

import model.EntityAction
import my.MovableUnit

interface UnitAction {
    fun perform(unit: MovableUnit): EntityAction
}