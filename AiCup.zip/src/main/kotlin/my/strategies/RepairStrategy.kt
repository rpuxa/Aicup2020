package my.strategies

import model.Vec2Int
import my.MovableUnit
import my.actions.MyRepairAction
import my.actions.NullAction
import my.actions.UnitAction
import my.entities
import my.properties
import my.view

class RepairStrategy(val pos: Vec2Int, val wait: () -> Unit) : UnitStrategy() {

    private var target: Int? = null

    override fun isFinished(unit: MovableUnit): Boolean {
        if (target == null) {
           target = view.entities.find { it.position == pos }?.id
        }
        val target = target ?: return false
        val entity = entities[target]
        return entity == null || entity.health == entity.properties.maxHealth
    }

    override fun perform(unit: MovableUnit): UnitAction? {
        if (isFinished(unit)) return null
        if (target == null){
            wait()
            return NullAction
        }
        return MyRepairAction(target!!)
    }
}