package my.strategies

import my.*
import my.actions.MyBuildAction
import my.actions.UnitAction

class BuildStrategy(val plan: BuildingPlan) : UnitStrategy(PRIORITY) {

    var strategy: UnitStrategy? = null

    var wait = 0

    override fun isFinished(unit: MovableUnit): Boolean {
        if (wait > 13) {
            plan.canceled = true
            return true
        }
        return strategy?.isFinished(unit) ?: false
    }

    override fun perform(unit: MovableUnit): UnitAction? {
        if (isFinished(unit)) return null
        var any = false
        val i = unit.pos.toI()
        baseNeighbours(plan.pos, plan.type.properties.size) {
            if (it == i) any = true
        }
        if (any) {
            if (strategy !is StrategyList) {
                strategy = StrategyList(
                        SingleActionStrategy(MyBuildAction(plan.type, plan.pos)) {
                            wait++
                            plan.cells.all { !occupied[it] }
                        },
                        RepairStrategy(plan.pos) {
                            wait++
                        }
                )
            }
        } else {
            queue.clear()
            val moveField = IntArray(size)
            baseNeighbours(plan.pos, plan.type.properties.size) {
                queue.push(it)
                moveField[it] = 60
            }
            bfs(notOccupiedGraph, queue, moveField)
            strategy = ChargeMoveStrategy(moveField)
        }
        return strategy!!.perform(unit)
    }

    companion object {
        const val PRIORITY = 2
    }
}