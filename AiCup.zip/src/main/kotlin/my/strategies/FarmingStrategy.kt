package my.strategies

import model.AttackAction
import my.*
import my.actions.MyAttackAction
import my.actions.MyMoveAction
import my.actions.UnitAction


class FarmingStrategy : UnitStrategy(PRIORITY) {

    override fun isFinished(unit: MovableUnit): Boolean {
        return false
    }

    override fun perform(unit: MovableUnit): UnitAction? {
        var place = unit.pos.toI()
        var max = farmersField[place]
        neighbours(place) {
            if (farmersField[it] > max) {
                place = it
                max = farmersField[it]
            }
        }
        if (isResource[place]) {
            return MyAttackAction(resources[place]!!.id)
        }
        val vector = place.toVec()
        return MyMoveAction(vector, false)
    }

    companion object {
        const val PRIORITY = 0
    }
}