package my.strategies

import my.*
import my.actions.MyMoveAction
import my.actions.NullAction
import my.actions.UnitAction

class FighterMoveStrategy : UnitStrategy() {

    var moveResult = -1

    override fun isFinished(unit: MovableUnit): Boolean {
        return false
    }

    fun wannaMove(unit: MovableUnit): Int {
        return path(unit.pos.toI(), ChargeMoveStrategy.chargeMove(fighterField, unit.pos.toI(), 100_000_000))
    }

    override fun perform(unit: MovableUnit): UnitAction? {
        val vector = moveResult.toVec()
        return if (vector == unit.pos) NullAction else MyMoveAction(vector, false)
    }
}